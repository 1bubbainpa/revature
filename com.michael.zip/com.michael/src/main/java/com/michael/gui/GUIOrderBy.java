package com.michael.gui;

import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;

import com.michael.models.Account;

import javax.swing.JLabel;
import java.awt.Font;
import javax.swing.JButton;
import java.awt.SystemColor;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class GUIOrderBy extends JFrame {

	private JPanel contentPane;
	private JButton btnInstructor;
	/**
	 * Create the frame.
	 */
	public GUIOrderBy(Account acc) 
	{
		setTitle("LiveBrary");
		setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		setBounds(100, 100, 450, 300);
		contentPane = new JPanel();
		contentPane.setBackground(SystemColor.activeCaption);
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel lblOrder = new JLabel("Order by...");
		lblOrder.setFont(new Font("Tahoma", Font.PLAIN, 16));
		lblOrder.setBounds(169, 32, 93, 42);
		contentPane.add(lblOrder);
		
		JButton btnCategory = new JButton("Category");
		btnCategory.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) 
			{
				GUIBrowse b = new GUIBrowse(acc, 1);
				b.setVisible(true);
				
			}
		});
		btnCategory.setBounds(78, 105, 125, 23);
		contentPane.add(btnCategory);
		
		JButton btnClassname = new JButton("Class Name");
		btnClassname.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) 
			{
				GUIBrowse b = new GUIBrowse(acc, 2);
				b.setVisible(true);
			}
		});
		btnClassname.setBounds(78, 153, 125, 23);
		contentPane.add(btnClassname);
		
		btnInstructor = new JButton("Teacher ID");
		btnInstructor.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) 
			{
				GUIBrowse b = new GUIBrowse(acc, 3);
				b.setVisible(true);
			}
		});
		btnInstructor.setBounds(213, 105, 121, 23);
		contentPane.add(btnInstructor);
		
		JButton btnMine = new JButton("My Classes");
		btnMine.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) 
			{
				GUIBrowse b = new GUIBrowse(acc, 4);
				b.setVisible(true);
			}
		});
		btnMine.setBounds(213, 153, 121, 23);
		contentPane.add(btnMine);
	}

}
