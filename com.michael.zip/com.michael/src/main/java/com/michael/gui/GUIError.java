package com.michael.gui;

import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;
import javax.swing.JButton;
import java.awt.Font;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class GUIError extends JFrame {

	private JPanel contentPane;

	/**
	 * Create the frame.
	 */
	public GUIError(String errorcode) 
	{
		setTitle("Warning");
		setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		setBounds(100, 100, 300, 230);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel lblError = new JLabel("Error:");
		lblError.setText(errorcode);
		lblError.setBounds(10, 58, 246, 44);
		contentPane.add(lblError);
		
		JButton btnAcknowledge = new JButton("OK");
		btnAcknowledge.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) 
			{
				dispose();
			}
		});
		btnAcknowledge.setFont(new Font("Tahoma", Font.BOLD, 11));
		btnAcknowledge.setBounds(92, 136, 89, 23);
		contentPane.add(btnAcknowledge);
	}
}
